McLawsuit

The font based on the �Golden Arches� logo for McDonald�s.


�2000 by Jesse Burgheimer
McDonald's, The Golden Arches, and the Golden Arches Logo are property of the McDonald's corporation. All rights reserved. Used without permission.
Version 1.2

This font is FREE. Freeware. No quarter asked, no quarter given.
Please do not redistribute without expressly written consent of the creator (Down10 aka Jesse Burgheimer).

Changes in 1.2:
- Adjusted line height.

Changes in 1.1:
- Added the Question Mark, by demand. But for what purpose???


Rationale: 
This is a font based entirely on the McDonald's "Golden arches." You know, the "M." I just took the original logo and sliced it up and pasted it together into an entire alphabet. It includes A-Z, 0-9, and all general punctuation, and keyboard characters.

The reason this font is called McLawsuit is that Micky-D's is valiant in protecting the intellectual property of their products, and it mostly comes across as pure dominance. But maybe they'll dig this font instead of wanting to slap me with some Cease and Desist order. Have you had your break today?


TRADEMARK INFORMATION 
(This is taken directly from the McDonald's web site, http://www.mcdonalds.com/. It is copied verbatim. Notice all the words and phrases, many which might have been considered public domain, that this one company now owns the rights to.)

The following trademarks used herein are owned by the McDonald's Corporation and its affiliates:
1-800-MC1-STCK, Always Quality. Always Fun., America�s Favorite Fries, Arch Deluxe, Aroma Caf�, Automac, Big Mac, Big N�Tasty, Big Xtra!, Birdie, the Early Bird and Design, Black History Makers of tomorrow, Bolshoi Mac, Boston Market, Cajita Feliz, Changing The Face of The World, Chicken McGrill, Chicken McNuggets, Chipolte Mexican Grill, Cuarto De Libra, Did Somebody Say , Donatos Pizza, emac digital, Egg McMuffin, Extra Value Meal, Filet-O-Fish, French Fry Box Design, Gep Op Mac, Golden Arches, Golden Arches Logo, Good Jobs For Good People, Good Times. Great Taste., Gospelfest, Great Breaks, Grimace and Design, Groenteburger, HACER, Hamburglar and Design, Hamburger University, Happy Meal, Happy Meal Box Design, Have You Had Your Break Today?, Healthy Growing Up, Helping Hands Logo, Hey, It Could Happen!, Iam Hungry and Design, Immunize for Healthy Lives, Lifting Kids To A Better Tomorrow, Mac Attack, Mac Jr., Mac Tonight and Design, McDonald�s Racing Team Design, Made For You, McBaby, McBacon, McBurger, McBus, McCafe, McChicken, McDia Feliz, MCDirect Shares, McDonaldland, McDonald�s , McDonald�s All American High School Basketball Game, McDonald�s All American High School Jazz Bank, McDonald�s All Star Racing Team, McDonald�s Building Design, McDonald�s Earth Effort, McDonald�s Earth Effort Logo, McDonald�s Express, McDonald�s Express Logo, McDonald�s Is Your Kind of Place, McDonald�s Means Opportunity, McDouble, McDrive, McExpress, McFamily, McFlurry, McFranchise, McGrilled Chicken, McHappy Day, McHero, McJobs, McKids, McKids Logo, McKroket, McMaco, McMemories, McMenu, McMusic, McNifica, McNuggets, McNuggets Kip, McOz, McPlane, McPollo, McPrep, McRecycle USA, McRib, McRoyal, McScholar, McScholar of the Year, McSwing, McWorld, Mighty Wings, Millennium Dreamers, Morning Mac, Quarter Pounder, RMHC, Ronald McDonald and Design, Ronald McDonald House, Ronald McDonald House Charities, Ronald McDonald House Charities Logo, Ronald McDonald House Logo, Ronald Scholars, Sausage McMuffin, Single Arch Logo, Speedee Logo, Super Size, Teriyaki McBurger, The House That Love Built, The House That Love Built Design, twoallbeefpattiesspecialsaucelettucecheesepicklesoniononasesameseedbun, Vegi Mac, We Love to See You Smile, What�s On Your Place, When the U.S. Wins You Win, World Famous Fries, You Deserve a Break Today, 

All other trademarks are the property of the respective trademark owners. 


Thanks for the download!

�Jesse D. Burgheimer \ Down10
jesse@down10.com
http://www.down10.com/